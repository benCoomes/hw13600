Ben Coomes
CPSC 3600
Jan 30 2016
Value Guesser Client / Value Server

To build: make
	view the makefile to see dependencies. 
	after running make, the two executables, 
	valueServer and valueGuesser, should be generated.

To run the server: $ ./valueServer -p <serverPort> [-v starting value]
	the starting value is an optional parameter, 
	the -v flag should be left off if it is not used

To run the client: $ ./valueGuesser -s <server IP> -p1 <server port 1> -p2 <server port 2>
	the server IP should be given in dotted format (IPV4 only)
	ex: 123.456.234.231
	Two ports must be provided

Basic server structure
	the server is started on the port specified on the command line
	it generates a starting 'hidden value', and then waits to revieve 
		a message from a client
	every time a message is recieved, the sender is examined.
	if the sender is unknown, the sender is added to a list of known clients
	the message is checked against the server's current 'hidden value'
	the server sends a message back to the client based on the comparison's results
	
	NOTE: the server will only terminate with a ^C command
	after termination, information about the server's life will be printed.


Basic client structure
	the client is started and attempts to connect to the server at the
		ip address and port number provided on the command line.
	NOTE: there is commented out section of code in the helper function
		'testSocket()'
		This dead code tried to perform a 'handshake' with the server
		to determine if the first port/ip combo worked
		The autograder does not like this. 
		That is why the code is not being used.

	the client then sends a message to the server with its first guess
	if no response is recieved from the server within a second, 
		the client tries to send the same guess again
	when a response is recieved, the client responds either by modifying the guess
		and then sending the new guess, or by terminating because the value 
		was guessed.
	the client exits either when ^C is issued or when it gets a message from the server
	which indicates that the correct value was guessed.





	

